# main.py
import asyncio
import json
import os
from pathlib import Path
from typing import List, Dict, Any
from src.crawler.playwright_crawler import PlaywrightCrawler
from src.analyzer.audit_runner import AuditRunner
from src.analyzer.result_processor import ResultProcessor
from src.utils.logger import setup_logger
from src.utils.config_manager import ConfigManager
from src.utils.report_utils import create_empty_report, create_error_report
from src.utils.ui_utils import print_banner

# --------------------------------------------------------------------------- #
# URL progress tracker                                                         #
# --------------------------------------------------------------------------- #
PROGRESS_FILE = "storage/url_progress.json"

def _load_progress() -> Dict:
    """Load saved progress from disk. Creates file if missing."""
    Path(PROGRESS_FILE).parent.mkdir(parents=True, exist_ok=True)
    if os.path.exists(PROGRESS_FILE):
        try:
            with open(PROGRESS_FILE, "r") as f:
                return json.load(f)
        except Exception:
            pass
    # File missing or corrupt — start fresh
    default = {"urls": [], "current_index": 0}
    _save_progress(default)
    return default

def _save_progress(data: Dict):
    """Persist progress to disk."""
    Path(PROGRESS_FILE).parent.mkdir(parents=True, exist_ok=True)
    with open(PROGRESS_FILE, "w") as f:
        json.dump(data, f, indent=2)

def _get_next_url(crawled_urls: List[str]) -> tuple:
    """
    Return (url, index) for the next URL to process.
    If all URLs are done, reset and start from the beginning.
    """
    progress = _load_progress()

    # If the crawled URL list changed, refresh it and reset index
    if progress.get("urls") != crawled_urls:
        progress = {"urls": crawled_urls, "current_index": 0}

    idx = progress["current_index"]

    if idx >= len(crawled_urls):
        # All done — reset for a fresh cycle
        idx = 0
        progress["current_index"] = 0
        _save_progress(progress)
        print(f"\n✅ All {len(crawled_urls)} URLs completed. Resetting to URL 1.\n")

    url = crawled_urls[idx]

    # Advance index for next run
    progress["current_index"] = idx + 1
    _save_progress(progress)

    return url, idx + 1  # return 1-based position for display


# --------------------------------------------------------------------------- #
# Main tool                                                                    #
# --------------------------------------------------------------------------- #
class AccessibilityAuditTool:
    def __init__(self, config_path: str = "config/config.yaml"):
        self.config_manager = ConfigManager(config_path)
        self.config = self.config_manager.config
        self.logger = setup_logger(__name__, self.config['logging']['level'])
        self.crawler = None
        self.audit_runner = None
        self.result_processor = None

    async def run_crawl(self) -> list:
        website_url = self.config['website']['url']
        try:
            self.crawler = PlaywrightCrawler(self.config)
            crawl_result = await self.crawler.crawl(website_url)
            if isinstance(crawl_result, dict) and 'urls' in crawl_result:
                return crawl_result['urls']
            elif isinstance(crawl_result, list):
                return crawl_result
            return []
        except Exception as e:
            self.logger.error(f"Crawling failed: {e}")
            raise
        finally:
            if self.crawler:
                await self.crawler.close()

    async def run_accessibility_audit(self, urls: List[str]) -> Dict[str, Any]:
        if not urls:
            return create_empty_report()
        try:
            self.audit_runner = AuditRunner(self.config)
            self.result_processor = ResultProcessor(self.config)
            audit_report = await self.audit_runner.run_audit(urls)
            report_paths = self.result_processor.save_audit_results(audit_report)
            return {'report': audit_report, 'output_paths': report_paths}
        except Exception as e:
            self.logger.error(f"Accessibility audit failed: {e}")
            return create_error_report(urls, str(e))

    async def run_comprehensive_audit(self, urls: List[str]) -> Dict[str, Any]:
        if not urls:
            return create_empty_report()
        try:
            from src.analyzer.integrated_audit_runner import IntegratedAuditRunner
            self.result_processor = ResultProcessor(self.config)
            integrated_runner = IntegratedAuditRunner(self.config)
            comprehensive_results = await integrated_runner.run_comprehensive_audit(urls)
            report_paths = self.result_processor.save_comprehensive_results(comprehensive_results)
            return {'report': comprehensive_results, 'output_paths': report_paths}
        except Exception as e:
            self.logger.error(f"Comprehensive audit failed: {e}")
            return await self.run_accessibility_audit(urls)

    async def run_single_url_audit(self, url: str, url_position: int,
                                   total_urls: int, audit_type: str = "comprehensive"):
        """Audit a single URL and save its own report."""
        print(f"\n🔍 Auditing URL {url_position}/{total_urls}: {url}\n")

        if audit_type == "comprehensive":
            comprehensive_results = await self.run_comprehensive_audit([url])
            basic_results = await self.run_accessibility_audit([url])
            return {
                "url": url,
                "url_position": url_position,
                "total_urls": total_urls,
                "comprehensive_audit": comprehensive_results,
                "basic_audit": basic_results,
                "audit_type": audit_type
            }
        else:
            basic_results = await self.run_accessibility_audit([url])
            return {
                "url": url,
                "url_position": url_position,
                "total_urls": total_urls,
                "basic_audit": basic_results,
                "audit_type": audit_type
            }

    async def run_full_audit(self, audit_type: str = "comprehensive"):
        # Hardcoded list of 17 URLs — crawler is skipped
        all_urls = [
            "https://kyngcapitalmanagement.envigo-tech.co.uk",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/investment-charter",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/privacy-policy",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/promotors",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/faqs",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/kyng-calculator",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/about-us",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/investment-philosophy",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/insights",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/contact",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/offerings",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/the-deleveraging-may-have-begun",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/investment",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/the-case-for-a-prolonged-recession",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/why-it-makes-sense-to-stay-out-of-this-bubble-in-indian-markets",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/nearing-the-crisis",
            "https://kyngcapitalmanagement.envigo-tech.co.uk/playing-with-fire",
        ]

        # Pick the next URL for this run
        url, position = _get_next_url(all_urls)

        # Audit just that one URL
        results = await self.run_single_url_audit(url, position, len(all_urls), audit_type)

        remaining = len(all_urls) - position
        if remaining > 0:
            print(f"\n📋 {remaining} URL(s) remaining. Run 'python main.py' again for the next URL.\n")
        else:
            print(f"\n🎉 All {len(all_urls)} URLs have been audited!\n")

        return results


# --------------------------------------------------------------------------- #
# Entry point                                                                  #
# --------------------------------------------------------------------------- #
async def main():
    print_banner()
    try:
        tool = AccessibilityAuditTool()

        choice = input("Enter audit type (1 for basic, 2 for comprehensive, default=2): ").strip()
        audit_type = "basic" if choice == "1" else "comprehensive"

        results = await tool.run_full_audit(audit_type)
        return results

    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    exit(exit_code)
