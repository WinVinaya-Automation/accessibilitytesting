import httpx
try:
    print("Connecting to health check...")
    with httpx.Client(timeout=5.0) as client:
        resp = client.get("http://127.0.0.1:8000/health")
        print(f"Status: {resp.status_code}")
        print(f"Body: {resp.text}")
except Exception as e:
    print(f"Failed: {e}")
