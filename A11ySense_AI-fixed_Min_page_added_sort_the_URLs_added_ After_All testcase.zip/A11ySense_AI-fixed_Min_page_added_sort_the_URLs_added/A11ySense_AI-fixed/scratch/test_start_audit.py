import httpx
payload = {
    "url": "https://example.com",
    "audit_type": "basic",
    "max_pages": 1,
    "max_depth": 1
}
try:
    print("Starting audit...")
    with httpx.Client(timeout=30.0) as client:
        resp = client.post("http://127.0.0.1:8000/start_audit", json=payload)
        print(f"Status: {resp.status_code}")
        print(f"Body: {resp.text}")
except Exception as e:
    print(f"Failed: {e}")
