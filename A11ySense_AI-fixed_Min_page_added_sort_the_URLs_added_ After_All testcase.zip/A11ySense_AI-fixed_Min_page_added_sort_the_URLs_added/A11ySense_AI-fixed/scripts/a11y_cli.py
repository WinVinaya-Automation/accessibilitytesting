import click
import httpx
import time
import json
import sys
from typing import Dict, Any

GATEWAY_URL = "http://127.0.0.1:8000"

# Timeout for the initial POST to start the audit (just needs to register the task)
START_TIMEOUT = 30.0

# Timeout for each status poll GET (generous, in case gateway is busy)
POLL_TIMEOUT = 60.0

@click.group()
def cli():
    """A11ySense AI CLI Tool for Accessibility Audits."""
    pass

@cli.command()
@click.argument('url')
@click.option('--type', 'audit_type', default='comprehensive', help='Audit type: basic or comprehensive')
@click.option('--min-page', default=1, help='Start from this page number (default: 1)')
@click.option('--max-pages', default=10, help='End at this page number (default: 10)')
@click.option('--max-depth', default=3, help='Maximum crawl depth')
@click.option('--wait', is_flag=True, help='Wait for the audit to complete')
def run(url, audit_type, min_page, max_pages, max_depth, wait):
    """Start an accessibility audit for the given URL.

    \b
    Examples:
      Run pages 1 to 2:
        python scripts/a11y_cli.py run https://lemonn.co.in/ --type comprehensive --min-page 1 --max-pages 2 --wait

      Run pages 6 to 10:
        python scripts/a11y_cli.py run https://lemonn.co.in/ --type comprehensive --min-page 6 --max-pages 10 --wait

      Run single page (page 3 only):
        python scripts/a11y_cli.py run https://lemonn.co.in/ --type comprehensive --min-page 3 --max-pages 3 --wait
    """

    # Validate range
    if min_page < 1:
        click.echo("Error: --min-page must be 1 or greater.", err=True)
        sys.exit(1)

    if max_pages < min_page:
        click.echo("Error: --max-pages must be >= --min-page.", err=True)
        sys.exit(1)

    payload = {
        "url": url,
        "audit_type": audit_type,
        "min_page": min_page,
        "max_pages": max_pages,
        "max_depth": max_depth
    }

    click.echo(f"\nAudit type  : {audit_type}")
    click.echo(f"Page range  : {min_page} to {max_pages}")
    click.echo(f"Target URL  : {url}\n")

    try:
        # Step 1: Start the audit (short timeout — just registers task)
        with httpx.Client(timeout=START_TIMEOUT) as client:
            response = client.post(f"{GATEWAY_URL}/start_audit", json=payload)
            response.raise_for_status()
            data = response.json()
            task_id = data["task_id"]
            click.echo(f"Audit started! Task ID: {task_id}")

        if not wait:
            click.echo(f"\nRun this to check status:")
            click.echo(f"  python scripts/a11y_cli.py status {task_id}")
            return

        # Step 2: Poll for status (separate client with longer timeout per request)
        click.echo("Waiting for audit to complete (this may take 15-60 minutes)...")
        printed_urls = False

        while True:
            try:
                with httpx.Client(timeout=POLL_TIMEOUT) as poll_client:
                    params = {"include_details": "true"} if not printed_urls else {"include_details": "false"}
                    status_resp = poll_client.get(f"{GATEWAY_URL}/task/{task_id}", params=params)
                    status_resp.raise_for_status()
                    status_data = status_resp.json()
                    status = status_data["status"]

                    # Print crawled URLs once
                    if not printed_urls and "urls_list" in status_data:
                        urls_list = status_data["urls_list"]
                        elements = status_data.get("elements", {})

                        # Warn if site had fewer URLs than requested
                        if "warning" in status_data:
                            click.echo(f"\n  ⚠ Warning: {status_data['warning']}")

                        actual_end = min_page + len(urls_list) - 1
                        click.echo(f"\n\n--- Crawl ended. Auditing {len(urls_list)} URL(s) (pages {min_page}-{actual_end}) ---")
                        for i, u in enumerate(urls_list, min_page):
                            click.echo(f"  {i}. {u}")

                        if elements:
                            click.echo("\n--- Accessibility Web Elements Discovered ---")
                            # Only show elements for the URLs that are actually being audited
                            # (the slice selected by min_page..max_pages), not all crawled pages.
                            selected_urls = set(urls_list)
                            elements_json = {
                                url_key: {
                                    "buttons": elems.get("buttons", 0),
                                    "inputs_selects": elems.get("inputs", 0),
                                    "links": elems.get("links", 0),
                                    "images": elems.get("images", 0),
                                    "headings": elems.get("headings", 0),
                                    "landmarks": elems.get("landmarks", 0),
                                }
                                for url_key, elems in elements.items()
                                if url_key in selected_urls
                            }
                            click.echo(json.dumps(elements_json, indent=2))

                        click.echo("----------------------------------------")
                        click.echo("Starting the audit process...\n")
                        printed_urls = True

                    if status == "completed":
                        click.echo("\nAudit completed successfully!")
                        click.echo(f"Report Paths:\n{json.dumps(status_data['report_paths'], indent=2)}")
                        break

                    elif status == "failed":
                        error_msg = status_data.get('error', 'Unknown error')
                        click.echo(f"\nAudit failed: {error_msg}")
                        click.echo("\nFull task details for debugging:")
                        click.echo(json.dumps(status_data, indent=2))
                        sys.exit(1)

                    else:
                        click.echo(f"  Status: {status}...", nl=False)
                        time.sleep(10)
                        click.echo("\r", nl=False)

            except httpx.TimeoutException:
                # Gateway took too long to respond to poll — not a failure, just retry
                click.echo("  Poll timed out, retrying in 15s...")
                time.sleep(15)

            except httpx.HTTPStatusError as e:
                click.echo(f"  Poll HTTP error: {e}, retrying in 15s...")
                time.sleep(15)

    except httpx.TimeoutException:
        click.echo(f"Error: Could not connect to Gateway at {GATEWAY_URL} (timeout).", err=True)
        sys.exit(1)

    except Exception as e:
        click.echo(f"Error connecting to Gateway at {GATEWAY_URL}: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument('task_id')
def status(task_id):
    """Check the status of an audit task."""
    try:
        with httpx.Client(timeout=POLL_TIMEOUT) as client:
            response = client.get(f"{GATEWAY_URL}/task/{task_id}")
            response.raise_for_status()
            data = response.json()
            click.echo(json.dumps(data, indent=2))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
def health():
    """Check the health of the Gateway service."""
    try:
        with httpx.Client(timeout=10.0) as client:
            response = client.get(f"{GATEWAY_URL}/health")
            response.raise_for_status()
            click.echo(f"Gateway is {response.json()['status']}")
    except Exception as e:
        click.echo(f"Gateway is unreachable: {e}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    cli()