from typing import List, Dict, Any, Optional
from selenium.webdriver.remote.webdriver import WebDriver
from axe_selenium_python import Axe
from ..models.extended_audit_models import AxeViolationResult


class AxeElementAnalyzer:
    def __init__(self, driver: WebDriver, logger):
        self.driver = driver
        self.logger = logger
        self._selector_index: Dict[str, List[AxeViolationResult]] = {}
        self._ran = False

    def run(self) -> None:
        try:
            print(" Axe Analyser: Starting...", flush=True)
            self.logger.info("AxeElementAnalyzer: running axe-core...")
            axe = Axe(self.driver)
            axe.inject()
            raw = axe.run()
            self._build_index(raw.get("violations", []))
            self._ran = True
            violations_count = len(raw.get("violations", []))
            print(f"Axe Analyser: Done — {violations_count} violations found, {len(self._selector_index)} selectors indexed", flush=True)
            self.logger.info(
                f"AxeElementAnalyzer: indexed {len(self._selector_index)} selectors "
                f"from {violations_count} violations"
            )
        except Exception as e:
            print(f"Axe Analyser: Failed — {e}", flush=True)
            self.logger.error(f"AxeElementAnalyzer: axe run failed: {e}")
        except Exception as e:
            self.logger.error(f"AxeElementAnalyzer: axe run failed: {e}")

    def get_for_selector(self, selector: Optional[str]) -> List[AxeViolationResult]:
        if not selector or not self._ran:
            return []
        return self._selector_index.get(self._normalise(selector), [])

    def _build_index(self, violations: List[Dict[str, Any]]) -> None:
        for violation in violations:
            result_base = dict(
                rule_id=violation.get("id", ""),
                impact=violation.get("impact", ""),
                description=violation.get("description", ""),
                help=violation.get("help", ""),
                help_url=violation.get("helpUrl", ""),
                tags=violation.get("tags", []),
            )
            for node in violation.get("nodes", []):
                result = AxeViolationResult(
                    **result_base,
                    html_snippet=node.get("html", ""),
                    failure_summary=node.get("failureSummary", ""),
                )
                for target in node.get("target", []):
                    key = self._normalise(str(target))
                    self._selector_index.setdefault(key, []).append(result)

    @staticmethod
    def _normalise(selector: str) -> str:
        return " ".join(selector.split())