# src/analyzer/extended_audits/extended_audit_runner.py
import asyncio
import time
from typing import List, Dict, Any
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

from ...core.exceptions import AnalysisException
from ...utils.logger import setup_logger
from ..models.extended_audit_models import ExtendedAuditResult

# Import the microservices
from .keyboard_audit import KeyboardAudit
from .screen_reader_audit import ScreenReaderAudit
from .landmark_audit import LandmarkAudit
from .skip_link_audit import SkipLinkAudit
from .axe_element_analyzer import AxeElementAnalyzer

class ExtendedAuditRunner:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = setup_logger(__name__)
        self.driver = None
        self.audit_services = {}
        self.axe_analyzer = None
    
    async def run_extended_audit(self, url: str) -> ExtendedAuditResult:
        """Run extended accessibility audits and return defects"""
        start_time = time.time()
        
        try:
            print(f"\n{'='*70}", flush=True)
            print("EXTENDED AUDIT RUNNER STARTED", flush=True)
            print(f"{'='*70}\n", flush=True)
            
            self.logger.info(f"Starting extended audit for: {url}")
            
            # Setup browser
            print("Step 1: Setting up browser...", flush=True)
            await self._setup_browser()
            print("Browser setup complete\n", flush=True)
            
            # Navigate to URL
            print(f"Step 2: Navigating to {url}...", flush=True)
            self.logger.info(f"Navigating to: {url}")
            self.driver.get(url)
            print("Page loaded\n", flush=True)
            
            # Wait for page to stabilize
            print("Step 3: Waiting for page to stabilize (5 seconds)...", flush=True)
            self.logger.info("Waiting for page to stabilize...")
            await asyncio.sleep(5)
            print("Page stabilized\n", flush=True)

            # NEW: Run axe-core once on the loaded page
            print("Step 4: Running AXE-CORE analysis...", flush=True)
            self.logger.info("Running axe-core analysis on loaded page...")
            self.axe_analyzer = AxeElementAnalyzer(self.driver, self.logger)
            self.axe_analyzer.run()
            print("Axe-core analysis complete\n", flush=True)
            
            # Initialize audit services
            print("Step 5: Initializing audit services...", flush=True)
            self._initialize_audit_services()
            print("Audit services initialized\n", flush=True)
            
            # Run all extended audits sequentially to avoid overload
            print("Step 6: Running keyboard navigation audit...", flush=True)
            self.logger.info("Starting keyboard navigation audit...")
            keyboard_defects = await self._run_audit_service("keyboard")
            print(f"Keyboard audit complete - {len(keyboard_defects)} defects found\n", flush=True)
            
            print("Step 7: Running screen reader audit...", flush=True)
            self.logger.info("Starting screen reader audit...")
            screen_reader_defects = await self._run_audit_service("screen_reader")
            print(f"Screen reader audit complete - {len(screen_reader_defects)} defects found\n", flush=True)
            
            print("Step 8: Running landmark audit...", flush=True)
            self.logger.info("Starting landmark audit...")
            landmark_defects = await self._run_audit_service("landmark")
            print(f"Landmark audit complete - {len(landmark_defects)} defects found\n", flush=True)
            
            print("Step 9: Running skip link audit...", flush=True)
            self.logger.info("Starting skip link audit...")
            skip_link_defects = await self._run_audit_service("skip_link")
            print(f"Skip link audit complete - {len(skip_link_defects)} defects found\n", flush=True)
            
            # Create result object
            result = ExtendedAuditResult(
                url=url,
                timestamp=time.strftime('%Y-%m-%d %H:%M:%S'),
                keyboard_defects=keyboard_defects,
                screen_reader_defects=screen_reader_defects,
                landmark_defects=landmark_defects,
                skip_link_defects=skip_link_defects
            )
            
            audit_duration = round(time.time() - start_time, 2)
            
            print(f"\n{'='*70}", flush=True)
            print("EXTENDED AUDIT SUMMARY", flush=True)
            print(f"{'='*70}", flush=True)
            print(f"Total Defects Found: {result.total_defects}", flush=True)
            print(f"  - Keyboard: {len(keyboard_defects)}", flush=True)
            print(f"  - Screen Reader: {len(screen_reader_defects)}", flush=True)
            print(f"  - Landmark: {len(landmark_defects)}", flush=True)
            print(f"  - Skip Links: {len(skip_link_defects)}", flush=True)
            print(f"Duration: {audit_duration}s", flush=True)
            print(f"{'='*70}\n", flush=True)
            
            self.logger.info(
                f"Extended audit completed for {url} in {audit_duration}s: "
                f"Found {result.total_defects} defects "
                f"(Keyboard: {len(keyboard_defects)}, "
                f"Screen Reader: {len(screen_reader_defects)}, "
                f"Landmark: {len(landmark_defects)}, "
                f"Skip Links: {len(skip_link_defects)})"
            )
            
            # Log defects by severity
            severity_counts = result.defects_by_severity
            if severity_counts:
                self.logger.info("Defects by severity:")
                for severity, count in severity_counts.items():
                    if count > 0:
                        self.logger.info(f"  {severity.value.upper()}: {count} defects")
            
            return result
            
        except Exception as e:
            print(f"\n EXTENDED AUDIT FAILED: {e}\n", flush=True)
            self.logger.error(f"Extended audit failed for {url}: {e}")
            return ExtendedAuditResult(
                url=url,
                timestamp=time.strftime('%Y-%m-%d %H:%M:%S'),
                keyboard_defects=[],
                screen_reader_defects=[],
                landmark_defects=[],
                skip_link_defects=[],
                error=str(e)
            )
        finally:
            await self._close_browser()
    
    def _initialize_audit_services(self):
        """Initialize all audit services"""
        self.audit_services = {
            "keyboard":      KeyboardAudit(self.driver, self.config, self.axe_analyzer),
            "screen_reader": ScreenReaderAudit(self.driver, self.config, self.axe_analyzer),
            "landmark":      LandmarkAudit(self.driver, self.config, self.axe_analyzer),
            "skip_link":     SkipLinkAudit(self.driver, self.config, self.axe_analyzer),
        }
    
    async def _run_audit_service(self, service_name: str) -> List[Any]:
        """Run a specific audit service with error handling"""
        try:
            service = self.audit_services.get(service_name)
            if service:
                self.logger.debug(f"Running {service_name} audit...")
                return await service.run_audit()
            return []
        except Exception as e:
            self.logger.error(f"Audit service {service_name} failed: {e}")
            return []
    
    async def _setup_browser(self):
        """Setup Chrome browser for extended testing"""
        chrome_options = Options()
        chrome_options.add_argument('--headless=new')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')
        chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
        
        # Performance optimizations
        chrome_options.add_argument('--disable-extensions')
        chrome_options.add_argument('--disable-plugins')
        chrome_options.add_argument('--disable-images')
        chrome_options.add_argument('--blink-settings=imagesEnabled=false')
        
        self.driver = webdriver.Chrome(
            service=Service(ChromeDriverManager().install()),
            options=chrome_options
        )
        
        # Set timeouts
        self.driver.implicitly_wait(10)
        self.driver.set_page_load_timeout(30)
        self.driver.set_script_timeout(30)
        
        self.logger.info("Browser setup completed")
    
    async def _close_browser(self):
        """Close browser instance"""
        if self.driver:
            try:
                self.driver.quit()
                self.logger.info("Browser closed successfully")
            except Exception as e:
                self.logger.warning(f"Error closing browser: {e}")