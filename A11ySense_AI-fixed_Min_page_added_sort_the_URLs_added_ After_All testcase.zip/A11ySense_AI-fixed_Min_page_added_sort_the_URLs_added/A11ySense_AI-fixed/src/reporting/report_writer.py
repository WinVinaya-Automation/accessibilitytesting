# src/utils/report_writer.py
import json
import pandas as pd
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
import os
from ..utils.logger import setup_logger

class ReportWriter:
    def __init__(self, base_output_dir: str = "storage/reports"):
        self.base_output_dir = Path(base_output_dir)
        self.json_dir = self.base_output_dir / "json"
        self.excel_dir = self.base_output_dir / "excel"
        self.logger = setup_logger(__name__)
        
        # Create directories
        self.json_dir.mkdir(parents=True, exist_ok=True)
        self.excel_dir.mkdir(parents=True, exist_ok=True)
    
    def save_json_report(self, data: Dict[str, Any], filename: str, 
                        timestamp: bool = True) -> str:
        """
        Save data as JSON report
        
        Args:
            data: Data to save as JSON
            filename: Base filename (without extension)
            timestamp: Whether to append timestamp to filename
            
        Returns:
            Path to the saved JSON file
        """
        try:
            # Generate filename
            if timestamp:
                timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"{filename}_{timestamp_str}.json"
            else:
                filename = f"{filename}.json"
            
            file_path = self.json_dir / filename
            
            # Make sure data is JSON serializable
            serializable_data = self._make_serializable(data)
            
            # Save as JSON
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(serializable_data, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"JSON report saved to: {file_path}")
            return str(file_path)
            
        except Exception as e:
            self.logger.error(f"Failed to save JSON report: {e}")
            raise
    
    def save_excel_report(self, data: Dict[str, Any], filename: str,
                         timestamp: bool = True) -> str:
        """
        Save data as Excel report with multiple sheets
        
        Args:
            data: Data to save as Excel (can contain multiple DataFrames)
            filename: Base filename (without extension)
            timestamp: Whether to append timestamp to filename
            
        Returns:
            Path to the saved Excel file
        """
        try:
            # Generate filename
            if timestamp:
                timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"{filename}_{timestamp_str}.xlsx"
            else:
                filename = f"{filename}.xlsx"
            
            file_path = self.excel_dir / filename
            
            with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
                # Process different types of data
                if isinstance(data, dict):
                    self._process_dict_data(data, writer)
                elif isinstance(data, list):
                    self._process_list_data(data, writer, filename)
                else:
                    # Convert single object to DataFrame
                    df = self._convert_to_dataframe(data, "Summary")
                    df.to_excel(writer, sheet_name="Summary", index=False)
            
            self.logger.info(f"Excel report saved to: {file_path}")
            return str(file_path)
            
        except Exception as e:
            self.logger.error(f"Failed to save Excel report: {e}")
            raise
    
    def save_comprehensive_audit_report(self, audit_data: Dict[str, Any], 
                                      filename: str) -> Dict[str, str]:
        """
        Save comprehensive audit report in both JSON and Excel formats
        
        Args:
            audit_data: Comprehensive audit data
            filename: Base filename (without extension)
            
        Returns:
            Dictionary with paths to saved files
        """
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_filename = f"{filename}_{timestamp_str}"
        
        json_path = self.save_json_report(audit_data, base_filename, timestamp=False)
        excel_path = self.save_excel_report(audit_data, base_filename, timestamp=False)
        
        return {
            'json': json_path,
            'excel': excel_path
        }
    
    def _process_dict_data(self, data: Dict[str, Any], writer: pd.ExcelWriter):
        """Process dictionary data for Excel export"""
        for sheet_name, sheet_data in data.items():
            if isinstance(sheet_data, (list, dict)):
                df = self._convert_to_dataframe(sheet_data, sheet_name)
                # Truncate sheet name if too long (Excel limit: 31 characters)
                safe_sheet_name = sheet_name[:31]
                df.to_excel(writer, sheet_name=safe_sheet_name, index=False)
    
    def _process_list_data(self, data: List[Any], writer: pd.ExcelWriter, filename: str):
        """Process list data for Excel export"""
        if data and isinstance(data[0], dict):
            df = self._convert_to_dataframe(data, filename)
            df.to_excel(writer, sheet_name="Data", index=False)
        else:
            # Simple list
            df = pd.DataFrame(data, columns=["Items"])
            df.to_excel(writer, sheet_name="Data", index=False)
    
    def _convert_to_dataframe(self, data: Any, sheet_name: str) -> pd.DataFrame:
        """Convert various data types to pandas DataFrame"""
        try:
            if isinstance(data, list):
                if data and isinstance(data[0], dict):
                    return pd.DataFrame(data)
                else:
                    return pd.DataFrame(data, columns=[sheet_name])
            elif isinstance(data, dict):
                # Flatten nested dictionaries
                flattened_data = self._flatten_dict(data)
                return pd.DataFrame([flattened_data])
            else:
                return pd.DataFrame([{"Value": str(data)}])
        except Exception as e:
            self.logger.warning(f"Failed to convert data to DataFrame for {sheet_name}: {e}")
            return pd.DataFrame([{"Error": "Failed to process data"}])
    
    def _flatten_dict(self, data: Dict[str, Any], parent_key: str = '', 
                     sep: str = '_') -> Dict[str, Any]:
        """Flatten nested dictionary for Excel export"""
        items = []
        for k, v in data.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(self._flatten_dict(v, new_key, sep=sep).items())
            elif isinstance(v, list):
                # Convert lists to string for Excel
                items.append((new_key, str(v)))
            else:
                items.append((new_key, v))
        return dict(items)
    
    def _make_serializable(self, obj: Any) -> Any:
        """Convert non-serializable objects to serializable formats"""
        if isinstance(obj, dict):
            return {k: self._make_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._make_serializable(item) for item in obj]
        elif isinstance(obj, (str, int, float, bool)) or obj is None:
            return obj
        elif hasattr(obj, '__dict__'):
            # Convert objects to dict
            return self._make_serializable(obj.__dict__)
        else:
            # Convert to string as fallback
            return str(obj)
    
    def generate_audit_excel_report(self, audit_report: Dict[str, Any], 
                                  filename: str) -> str:
        """
        Generate a comprehensive Excel report specifically for audit results.
        Each row represents one affected element (node), so if a rule affects
        500 elements you will get 500 rows — not 1.
        
        Args:
            audit_report: Audit report data
            filename: Base filename
            
        Returns:
            Path to saved Excel file
        """
        try:
            timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{filename}_{timestamp_str}.xlsx"
            file_path = self.excel_dir / filename
            
            with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
                # Summary Sheet
                if 'summary' in audit_report:
                    summary_data = self._prepare_summary_data(audit_report['summary'])
                    summary_df = pd.DataFrame([summary_data])
                    summary_df.to_excel(writer, sheet_name="Summary", index=False)
                
                # Violations + Passes combined sheet — one row per element
                if 'page_results' in audit_report:
                    violations_data = self._prepare_detailed_violations_data(audit_report['page_results'])
                    passes_data = self._prepare_detailed_passes_data(audit_report['page_results'])
                    combined_data = violations_data + passes_data
                    if combined_data:
                        combined_df = pd.DataFrame(combined_data)
                        combined_df.to_excel(writer, sheet_name="Violations_Detailed", index=False)
                
                # Passes only sheet — one row per element
                if 'page_results' in audit_report:
                    passes_data = self._prepare_detailed_passes_data(audit_report['page_results'])
                    if passes_data:
                        passes_df = pd.DataFrame(passes_data)
                        passes_df.to_excel(writer, sheet_name="Passes", index=False)
                
                # Extended Audit Defects Sheet
                if 'page_results' in audit_report:
                    extended_defects_data = self._prepare_extended_defects_data(audit_report['page_results'])
                    if extended_defects_data:
                        extended_df = pd.DataFrame(extended_defects_data)
                        extended_df.to_excel(writer, sheet_name="Extended_Defects", index=False)
                
                # Page Results Sheet
                if 'page_results' in audit_report:
                    page_results_data = self._prepare_page_results_data(audit_report['page_results'])
                    if page_results_data:
                        page_results_df = pd.DataFrame(page_results_data)
                        page_results_df.to_excel(writer, sheet_name="Page_Results", index=False)
                
                # Violations Summary Sheet
                if 'page_results' in audit_report:
                    violations_summary_data = self._prepare_violations_summary_data(audit_report['page_results'])
                    if violations_summary_data:
                        violations_summary_df = pd.DataFrame(violations_summary_data)
                        violations_summary_df.to_excel(writer, sheet_name="Violations_Summary", index=False)
            
            self.logger.info(f"Comprehensive audit Excel report saved to: {file_path}")
            return str(file_path)
            
        except Exception as e:
            self.logger.error(f"Failed to generate audit Excel report: {e}")
            raise
    
    def _prepare_summary_data(self, summary: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare summary data for Excel export"""
        summary_data = {}
        
        # Basic metrics
        basic_metrics = ['total_pages', 'pages_audited', 'total_violations', 
                        'average_score', 'audit_duration']
        for metric in basic_metrics:
            if metric in summary:
                summary_data[metric] = summary[metric]
        
        # Extended defects
        if 'total_extended_defects' in summary:
            summary_data['total_extended_defects'] = summary['total_extended_defects']
        
        # Violations by level
        if 'violations_by_level' in summary:
            for level, count in summary['violations_by_level'].items():
                summary_data[f'violations_{level}'] = count
        
        # Extended defects by category
        if 'extended_defects_by_category' in summary:
            for category, count in summary['extended_defects_by_category'].items():
                summary_data[f'defects_{category}'] = count
        
        return summary_data
    
    def _prepare_detailed_violations_data(self, page_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Prepare detailed violations data for Excel export.

        KEY CHANGE: Each axe rule can affect many elements (nodes). Previously
        this method produced one row per rule, collapsing all affected elements
        into a single cell. Now it produces ONE ROW PER NODE (element), so a
        rule that flags 200 elements contributes 200 rows. This matches the
        expected behaviour where row count == total elements tested.

        If a violation has zero nodes (unusual but possible), one fallback row
        is still written so the rule is not silently dropped.
        """
        violations_data = []
        
        for page in page_results:
            url = page.get('url', 'Unknown')
            page_title = page.get('page_title', 'Unknown')
            testing_mode = "Automation"
            
            for violation in page.get('violations', []):
                nodes = violation.get('nodes', [])

                # --- shared rule-level fields (same for every node row) ---
                rule_id          = violation.get('id', '')
                standards        = self._extract_wcag_criteria(violation)
                level            = self._derive_level(violation)
                expected_result  = violation.get('expected_result', '')
                actual_result    = violation.get('actual_result', '')
                description      = violation.get('llm_description', '') or violation.get('description', '')
                severity         = violation.get('impact', '').capitalize() if violation.get('impact') else ''
                priority         = self._impact_to_priority(violation.get('impact', ''))
                help_text        = violation.get('help', '')
                ai_fix           = violation.get('ai_suggested_fix', '')
                steps            = violation.get('steps_to_reproduce', '')

                if not nodes:
                    # Fallback: write one row with no element-specific data
                    violations_data.append({
                        'URL': url,
                        'Page Title': page_title,
                        'testing_mode': testing_mode,
                        'Criteria': rule_id,
                        'Standards': standards,
                        'Level': level,
                        'Expected Result': expected_result,
                        'Actual Result': actual_result,
                        'Description': description,
                        'Severity': severity,
                        'Priority': priority,
                        'Status': 'Fail',
                        'Help': help_text,
                        'HTML Snippet': 'No specific elements',
                        'Computed Styles': '',
                        'AI Suggested/Recommended Fixes': ai_fix,
                        'Steps to Reproduce': steps
                    })
                else:
                    # ONE ROW PER NODE — no slice limit
                    for node in nodes:
                        html_snippet = self._extract_node_html(node)
                        # Per-node actual result: prefer node-level check messages
                        node_actual_result = actual_result or self._extract_node_check_messages(node)

                        violations_data.append({
                            'URL': url,
                            'Page Title': page_title,
                            'testing_mode': testing_mode,
                            'Criteria': rule_id,
                            'Standards': standards,
                            'Level': level,
                            'Expected Result': expected_result,
                            'Actual Result': node_actual_result,
                            'Description': description,
                            'Severity': severity,
                            'Priority': priority,
                            'Status': 'Fail',
                            'Help': help_text,
                            'HTML Snippet': html_snippet,
                            'Computed Styles': '',
                            'AI Suggested/Recommended Fixes': ai_fix,
                            'Steps to Reproduce': steps
                        })
        
        return violations_data
    
    def _prepare_detailed_passes_data(self, page_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Prepare pass results data for Excel export.

        KEY CHANGE: Same as violations — previously one row per rule,
        now ONE ROW PER NODE (element) so pass counts also reflect the
        true number of elements checked. Nodes list is no longer sliced.
        """
        passes_data = []
        
        for page in page_results:
            url = page.get('url', 'Unknown')
            page_title = page.get('page_title', 'Unknown')
            testing_mode = "Automation"
            
            for pass_item in page.get('passes', []):
                wcag_tags = [tag for tag in pass_item.get('tags', []) if tag.startswith('wcag')]
                nodes     = pass_item.get('nodes', [])

                # --- shared rule-level fields ---
                rule_id  = pass_item.get('id', '')
                standards = ', '.join(wcag_tags) if wcag_tags else 'Not specified'
                level    = self._derive_level(pass_item)
                help_text = pass_item.get('help', '')
                description = pass_item.get('llm_description', '') or pass_item.get('description', '')

                # Rule-level LLM / derived fields (used as fallback per node)
                rule_expected = (
                    pass_item.get('expected_result', '')
                    or self._derive_pass_expected_result(pass_item)
                )
                rule_steps = (
                    pass_item.get('steps_to_reproduce', '')
                    or self._derive_pass_steps(pass_item)
                )

                if not nodes:
                    # Fallback: one row with no element-specific data
                    passes_data.append({
                        'URL': url,
                        'Page Title': page_title,
                        'testing_mode': testing_mode,
                        'Criteria': rule_id,
                        'Standards': standards,
                        'Level': level,
                        'Expected Result': rule_expected,
                        'Actual Result': self._derive_pass_actual_result(pass_item),
                        'Description': description,
                        'Severity': 'N/A',
                        'Priority': 'N/A',
                        'Status': 'Pass',
                        'Help': help_text,
                        'HTML Snippet': 'No specific elements',
                        'Computed Styles': '',
                        'AI Suggested/Recommended Fixes': 'N/A',
                        'Steps to Reproduce': rule_steps
                    })
                else:
                    # ONE ROW PER NODE — no slice limit
                    for node in nodes:
                        html_snippet = self._extract_node_html(node)
                        # Per-node actual result: prefer node-level check messages
                        node_actual = (
                            pass_item.get('actual_result', '')
                            or self._extract_node_check_messages(node)
                            or self._derive_pass_actual_result_from_help(pass_item)
                        )

                        passes_data.append({
                            'URL': url,
                            'Page Title': page_title,
                            'testing_mode': testing_mode,
                            'Criteria': rule_id,
                            'Standards': standards,
                            'Level': level,
                            'Expected Result': rule_expected,
                            'Actual Result': node_actual,
                            'Description': description,
                            'Severity': 'N/A',
                            'Priority': 'N/A',
                            'Status': 'Pass',
                            'Help': help_text,
                            'HTML Snippet': html_snippet,
                            'Computed Styles': '',
                            'AI Suggested/Recommended Fixes': 'N/A',
                            'Steps to Reproduce': rule_steps
                        })
        
        return passes_data

    # ------------------------------------------------------------------
    # Node-level helper methods (new)
    # ------------------------------------------------------------------

    def _extract_node_html(self, node: Dict[str, Any]) -> str:
        """
        Extract the best available HTML identifier for a single node.
        Priority order:
          1. node['html']  — the actual HTML snippet axe captures
          2. node['target'] — CSS selector(s)
          3. Fallback string
        """
        # axe stores the raw outer HTML of the offending element here
        html = node.get('html', '').strip()
        if html:
            return html

        # Fall back to the CSS selector target
        target = node.get('target', [])
        if target:
            first = target[0] if isinstance(target, list) else target
            if isinstance(first, list):
                return ' > '.join(str(s) for s in first)
            return str(first)

        return 'No element data'

    def _extract_node_check_messages(self, node: Dict[str, Any]) -> str:
        """
        Pull check messages from a single node's any/all/none groups.
        These give element-specific reasons why it passed or failed.
        Returns a semicolon-separated string of unique messages.
        """
        messages = []
        for check_group in ('any', 'all', 'none'):
            for check in node.get(check_group, []):
                msg = check.get('message') or ''   # guard against None
                msg = str(msg).strip()
                if msg and msg not in messages:
                    messages.append(msg)
        return '; '.join(messages) if messages else ''

    # ------------------------------------------------------------------
    # Rule-level derived-field helpers (retained from original)
    # ------------------------------------------------------------------

    def _derive_pass_expected_result(self, pass_item: Dict[str, Any]) -> str:
        """Build expected result from axe help text and tags when LLM data is absent."""
        help_text = pass_item.get('help', '') or pass_item.get('description', '')
        wcag_tags = [t for t in pass_item.get('tags', []) if t.startswith('wcag') and len(t) > 5]
        if wcag_tags:
            return f"{help_text}. Must comply with: {', '.join(wcag_tags)}."
        return help_text

    def _derive_pass_actual_result(self, pass_item: Dict[str, Any]) -> str:
        """
        Build actual result by scanning ALL nodes (no slice limit).
        Collects unique check messages across the entire node list.
        """
        nodes = pass_item.get('nodes', [])
        messages = []
        for node in nodes:                          # ← was nodes[:3]
            for check_group in ('any', 'all', 'none'):
                for check in node.get(check_group, []):
                    msg = check.get('message', '')
                    if msg and msg not in messages:
                        messages.append(msg)
        if messages:
            return '; '.join(messages[:5])          # cap summary to 5 unique messages
        help_text = pass_item.get('help', '') or pass_item.get('description', '')
        return f"The page passes this check: {help_text}."

    def _derive_pass_actual_result_from_help(self, pass_item: Dict[str, Any]) -> str:
        """Lightweight fallback when a node has no check messages."""
        help_text = pass_item.get('help', '') or pass_item.get('description', '')
        return f"The page passes this check: {help_text}."

    def _derive_pass_steps(self, pass_item: Dict[str, Any]) -> str:
        """Build verification steps from axe rule metadata when LLM data is absent."""
        rule_id = pass_item.get('id', '')
        help_text = pass_item.get('help', '')
        help_url = pass_item.get('helpUrl', '')
        step4 = f"Verify that the rule '{rule_id}' passes: {help_text}."
        steps = [
            "1. Open the page in Google Chrome.",
            "2. Open Chrome DevTools (F12) and navigate to the Accessibility panel.",
            "3. Inspect the elements listed in the HTML Snippet column using the Elements panel.",
            f"4. {step4}",
            "5. Confirm no violation is reported for this rule in the axe DevTools extension.",
        ]
        if help_url:
            steps.append(f"6. Refer to the rule documentation for further details: {help_url}")
        return '\n'.join(steps)
    
    def _prepare_violations_summary_data(self, page_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Prepare violations summary data grouped by violation type"""
        violations_summary = {}
        
        for page in page_results:
            if 'violations' in page:
                for violation in page['violations']:
                    violation_id = violation.get('id', 'unknown')
                    if violation_id not in violations_summary:
                        violations_summary[violation_id] = {
                            'violation_id': violation_id,
                            'violation_description': violation.get('description', ''),
                            'violation_impact': violation.get('impact', ''),
                            'violation_level': violation.get('level', ''),
                            'total_occurrences': 0,
                            'pages_affected': set(),
                            'total_elements_affected': 0,
                            'help_url': violation.get('help_url', '')
                        }
                    
                    violations_summary[violation_id]['total_occurrences'] += 1
                    violations_summary[violation_id]['pages_affected'].add(page.get('url', 'Unknown'))
                    violations_summary[violation_id]['total_elements_affected'] += len(violation.get('nodes', []))
        
        # Convert to list and format pages_affected
        summary_data = []
        for violation in violations_summary.values():
            summary_data.append({
                'violation_id': violation['violation_id'],
                'violation_description': violation['violation_description'],
                'violation_impact': violation['violation_impact'],
                'violation_level': violation['violation_level'],
                'total_occurrences': violation['total_occurrences'],
                'pages_affected_count': len(violation['pages_affected']),
                'total_elements_affected': violation['total_elements_affected'],
                'help_url': violation['help_url']
            })
        
        return summary_data
    
    def _prepare_extended_defects_data(self, page_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Prepare extended defects data for Excel export with uniform columns"""
        defects_data = []

        severity_map = {
            'critical': 'Critical', 'high': 'High',
            'medium': 'Medium', 'low': 'Low'
        }

        for page in page_results:
            url = page.get('url', 'Unknown')
            page_title = page.get('page_title', 'Unknown')
            extended_audit = page.get('extended_audit', {})

            # Keyboard defects
            for defect in extended_audit.get('keyboard_defects', []):
                defects_data.append({
                    'URL': url,
                    'Page Title': page_title,
                    'Defect Type': 'Keyboard',
                    'Element Type': defect.get('element_type', ''),
                    'Element Description': defect.get('element_description', ''),
                    'Issue': defect.get('issue', ''),
                    'Severity': severity_map.get(defect.get('severity', '').lower(), defect.get('severity', '')),
                    'Recommendation': defect.get('recommendation', ''),
                    'Selector / Target': defect.get('selector', ''),
                    'Expected Result': defect.get('expected_result', ''),
                    'Actual Result': defect.get('actual_result', ''),
                    'Steps to Reproduce': defect.get('steps_to_reproduce', ''),
                    'AI Suggested/Recommended Fixes': defect.get('ai_suggested_fix', '')
                })

            # Screen reader defects
            for defect in extended_audit.get('screen_reader_defects', []):
                defects_data.append({
                    'URL': url,
                    'Page Title': page_title,
                    'Defect Type': 'Screen Reader',
                    'Element Type': defect.get('element_type', ''),
                    'Element Description': defect.get('element_description', ''),
                    'Issue': defect.get('issue', ''),
                    'Severity': severity_map.get(defect.get('severity', '').lower(), defect.get('severity', '')),
                    'Recommendation': defect.get('recommendation', ''),
                    'Selector / Target': defect.get('selector', ''),
                    'Expected Result': defect.get('expected_result', ''),
                    'Actual Result': defect.get('actual_result', ''),
                    'Steps to Reproduce': defect.get('steps_to_reproduce', ''),
                    'AI Suggested/Recommended Fixes': defect.get('ai_suggested_fix', '')
                })

            # Landmark defects
            for defect in extended_audit.get('landmark_defects', []):
                defects_data.append({
                    'URL': url,
                    'Page Title': page_title,
                    'Defect Type': 'Landmark',
                    'Element Type': defect.get('landmark_type', '').replace('_', ' ').title(),
                    'Element Description': defect.get('element_description', ''),
                    'Issue': defect.get('issue', ''),
                    'Severity': severity_map.get(defect.get('severity', '').lower(), defect.get('severity', '')),
                    'Recommendation': defect.get('recommendation', ''),
                    'Selector / Target': defect.get('selector', ''),
                    'Expected Result': defect.get('expected_result', ''),
                    'Actual Result': defect.get('actual_result', ''),
                    'Steps to Reproduce': defect.get('steps_to_reproduce', ''),
                    'AI Suggested/Recommended Fixes': defect.get('ai_suggested_fix', '')
                })

            # Skip link defects
            for defect in extended_audit.get('skip_link_defects', []):
                defects_data.append({
                    'URL': url,
                    'Page Title': page_title,
                    'Defect Type': 'Skip Link',
                    'Element Type': 'Skip Link',
                    'Element Description': f"Target: {defect.get('target_id', 'N/A')}",
                    'Issue': defect.get('issue', ''),
                    'Severity': severity_map.get(defect.get('severity', '').lower(), defect.get('severity', '')),
                    'Recommendation': defect.get('recommendation', ''),
                    'Selector / Target': defect.get('target_id', ''),
                    'Expected Result': defect.get('expected_result', ''),
                    'Actual Result': defect.get('actual_result', ''),
                    'Steps to Reproduce': defect.get('steps_to_reproduce', ''),
                    'AI Suggested/Recommended Fixes': defect.get('ai_suggested_fix', '')
                })

        return defects_data
    
    def _prepare_page_results_data(self, page_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Prepare detailed page results for Excel export"""
        detailed_data = []
        
        for page in page_results:
            page_data = {
                'page_url': page.get('url', ''),
                'page_title': page.get('page_title', 'Unknown'),
                'testing_mode': 'Automation',
                'accessibility_score': page.get('score', 0),
                'total_violations': page.get('violation_count', 0),
                'total_passes': len(page.get('passes', [])),
                'load_time_seconds': page.get('load_time', 0),
                'error_message': page.get('error', ''),
                'audit_timestamp': page.get('timestamp', '')
            }
            
            # Add violations breakdown
            if 'violations' in page:
                violations_by_level = {}
                for violation in page['violations']:
                    level = violation.get('level', 'unknown')
                    violations_by_level[level] = violations_by_level.get(level, 0) + 1
                
                for level in ['critical', 'serious', 'moderate', 'minor']:
                    page_data[f'violations_{level}'] = violations_by_level.get(level, 0)
            
            # Add extended audit summary
            extended_audit = page.get('extended_audit', {})
            if extended_audit:
                page_data['total_extended_defects'] = extended_audit.get('total_defects', 0)
                page_data['keyboard_defects'] = extended_audit.get('defects_by_category', {}).get('keyboard', 0)
                page_data['screen_reader_defects'] = extended_audit.get('defects_by_category', {}).get('screen_reader', 0)
                page_data['landmark_defects'] = extended_audit.get('defects_by_category', {}).get('landmark', 0)
                page_data['skip_link_defects'] = extended_audit.get('defects_by_category', {}).get('skip_links', 0)
            
            detailed_data.append(page_data)
        
        return detailed_data
    
    def _extract_wcag_criteria(self, violation: Dict[str, Any]) -> str:
        """Extract WCAG criteria from violation tags"""
        tags = violation.get('tags', [])
        wcag_tags = [tag for tag in tags if tag.startswith('wcag')]
        return ', '.join(wcag_tags) if wcag_tags else 'Not specified'
    
    def _derive_level(self, item: Dict[str, Any]) -> str:
        """Derive WCAG Level from tags: wcag2aa → Level AA, wcag2a → Level A, else Level N/A"""
        tags = item.get('tags', [])
        if any(tag == 'wcag2aa' for tag in tags):
            return 'Level AA'
        if any(tag == 'wcag2a' for tag in tags):
            return 'Level A'
        return 'Level N/A'

    def _impact_to_priority(self, impact: str) -> str:
        """Map axe impact level to Priority"""
        return {
            'critical': 'High',
            'serious': 'High',
            'moderate': 'Medium',
            'minor': 'Low'
        }.get(impact.lower() if impact else '', 'Medium')
    
    def _extract_element_selectors(self, violation: Dict[str, Any]) -> str:
        """
        Extract element selectors from ALL violation nodes (no slice limit).
        NOTE: This method is kept for backward compatibility but is no longer
        called by _prepare_detailed_violations_data. That method now uses
        _extract_node_html() directly inside its per-node loop so each row
        gets its own individual element selector instead of a joined list.
        """
        nodes = violation.get('nodes', [])
        selectors = []
        
        for node in nodes:                          # ← was nodes[:5]
            target = node.get('target', [])
            if target:
                first = target[0] if isinstance(target, list) else target
                if isinstance(first, list):
                    selectors.append(' > '.join(str(s) for s in first))
                else:
                    selectors.append(str(first))
        
        return '; '.join(selectors) if selectors else 'No specific elements'
    
    def _generate_recommendation(self, violation: Dict[str, Any]) -> str:
        """Generate a recommendation based on violation type"""
        violation_id = violation.get('id', '')
        help_text = violation.get('help', '')
        
        recommendations = {
            'empty-heading': 'Add meaningful text content to empty heading elements.',
            'frame-title': 'Add descriptive title attribute to iframe elements.',
            'landmark-one-main': 'Ensure only one main landmark exists per page.',
            'link-name': 'Add descriptive text or aria-label to links.',
            'meta-viewport': 'Ensure viewport meta tag allows zooming and scaling.',
            'page-has-heading-one': 'Add at least one h1 heading to the page.',
            'region': 'Ensure all content is contained within appropriate landmarks.'
        }
        
        return recommendations.get(violation_id, help_text)