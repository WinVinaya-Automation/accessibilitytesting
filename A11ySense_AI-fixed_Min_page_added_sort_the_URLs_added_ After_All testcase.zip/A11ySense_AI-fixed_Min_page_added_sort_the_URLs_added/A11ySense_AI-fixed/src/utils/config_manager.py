import yaml
import os
from pathlib import Path
from typing import Dict, Any
from dotenv import load_dotenv

class ConfigManager:
    def __init__(self, config_path: str = "config/config.yaml"):
        self.config_path = config_path
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Load and validate configuration"""
        config_file = Path(self.config_path)

        # Resolve to absolute path using this file's actual location on disk
        if not config_file.is_absolute():
            config_file = Path(__file__).parent.parent.parent / config_file

        if not config_file.exists():
            raise FileNotFoundError(f"Config file not found: {config_file}")

        # Load .env BEFORE reading YAML so ${GROQ_API_KEY} substitution works
        project_root = config_file.parent.parent
        dotenv_path = project_root / ".env"
        if dotenv_path.exists():
            load_dotenv(dotenv_path=str(dotenv_path), override=True)
        else:
            load_dotenv(override=True)

        with open(config_file, 'r') as file:
            config = yaml.safe_load(file)

        # Replace environment variable placeholders
        config = self._replace_env_variables(config)
        
        # Validate required settings
        self._validate_config(config)
        
        return config
    
    def _replace_env_variables(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Replace environment variable placeholders in config"""
        def replace_recursive(obj):
            if isinstance(obj, dict):
                return {k: replace_recursive(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [replace_recursive(item) for item in obj]
            elif isinstance(obj, str) and obj.startswith("${") and obj.endswith("}"):
                env_var = obj[2:-1]
                value = os.getenv(env_var)
                if value is None:
                    return ""  # Empty string → GroqClient disables itself gracefully
                return value
            return obj

        return replace_recursive(config)
    
    def _validate_config(self, config: Dict[str, Any]):
        """Validate configuration parameters"""
        # Validate website URL
        website_url = config.get('website', {}).get('url', '')
        if not website_url or website_url == "https://example.com":
            raise ValueError("Please update 'website.url' in config.yaml with your target website")
        
        if not website_url.startswith(('http://', 'https://')):
            raise ValueError("Website URL must start with http:// or https://")
        
        # Validate max pages
        max_pages = config.get('website', {}).get('max_pages', 1000)
        if not isinstance(max_pages, int) or max_pages <= 0:
            raise ValueError("website.max_pages must be a positive integer")
    
    def get_website_url(self) -> str:
        """Get target website URL"""
        return self.config['website']['url']
    
    def get_website_name(self) -> str:
        """Get website display name"""
        return self.config['website'].get('name', self.get_website_url())
    
    def get_max_pages(self) -> int:
        """Get maximum pages to crawl"""
        return self.config['website']['max_pages']
    
    def is_sitemap_validation_enabled(self) -> bool:
        """Check if sitemap validation is enabled"""
        return self.config['website'].get('enable_sitemap_validation', True)