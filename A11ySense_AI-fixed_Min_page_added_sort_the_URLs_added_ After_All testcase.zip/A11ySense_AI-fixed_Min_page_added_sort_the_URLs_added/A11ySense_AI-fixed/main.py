# main.py
import asyncio
import argparse
from typing import List, Dict, Any
from src.crawler.playwright_crawler import PlaywrightCrawler
from src.analyzer.audit_runner import AuditRunner
from src.analyzer.result_processor import ResultProcessor
from src.llm.groq_client import GroqClient
from src.utils.logger import setup_logger
from src.utils.config_manager import ConfigManager
from src.utils.report_utils import create_empty_report, create_error_report
from src.utils.ui_utils import print_banner
from src.analyzer.integrated_audit_runner import IntegratedAuditRunner


class AccessibilityAuditTool:
    def __init__(self, config_path: str = "config/config.yaml"):
        self.config_manager = ConfigManager(config_path)
        self.config = self.config_manager.config
        self.logger = setup_logger(__name__, self.config['logging']['level'])
        self.crawler = None
        self.audit_runner = None
        self.result_processor = None

    async def run_crawl(self) -> list:
        website_url = self.config['website']['url']

        try:
            self.crawler = PlaywrightCrawler(self.config)
            crawl_result = await self.crawler.crawl(website_url)

            if isinstance(crawl_result, dict) and 'urls' in crawl_result:
                return crawl_result['urls']
            elif isinstance(crawl_result, list):
                return crawl_result
            return []

        except Exception as e:
            self.logger.error(f"Crawling failed: {e}")
            raise
        finally:
            if self.crawler:
                await self.crawler.close()

    async def run_llm_analysis(self, audit_report: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Run LLM analysis to get expected/actual result per element"""
        try:
            self.logger.info("Starting LLM analysis...")
            client = GroqClient(self.config)
            llm_results = await client.analyze_audit_results(audit_report)
            self.logger.info(f"LLM analysis completed for {len(llm_results)} pages.")
            return llm_results
        except Exception as e:
            self.logger.error(f"LLM analysis failed: {e}")
            return []

    def _merge_llm_into_report(self, audit_report: Dict[str, Any], llm_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Merge LLM expected/actual results into the audit report per page"""
        # Build lookup by url
        llm_by_url = {item['url']: item for item in llm_results}

        for page in audit_report.get('page_results', []):
            url = page.get('url', '')
            llm_page = llm_by_url.get(url, {})
            llm_elements = llm_page.get('elements', [])

            # Build lookup by rule_id
            llm_by_rule = {e['rule_id']: e for e in llm_elements}

            # Merge into violations
            for violation in page.get('violations', []):
                rule_id = violation.get('id', '')
                if rule_id in llm_by_rule:
                    violation['expected_result'] = llm_by_rule[rule_id].get('expected_result', '')
                    violation['actual_result'] = llm_by_rule[rule_id].get('actual_result', '')
                    violation['llm_description'] = llm_by_rule[rule_id].get('description', '')

            # Merge into passes
            for pass_item in page.get('passes', []):
                rule_id = pass_item.get('id', '')
                if rule_id in llm_by_rule:
                    pass_item['expected_result'] = llm_by_rule[rule_id].get('expected_result', '')
                    pass_item['actual_result'] = llm_by_rule[rule_id].get('actual_result', '')
                    pass_item['llm_description'] = llm_by_rule[rule_id].get('description', '')

        return audit_report

    async def run_accessibility_audit(self, urls: List[str]) -> Dict[str, Any]:
        if not urls:
            return create_empty_report()

        try:
            self.audit_runner = AuditRunner(self.config)
            self.result_processor = ResultProcessor(self.config)

            # Run accessibility audit
            audit_report = await self.audit_runner.run_audit(urls)

            # Run LLM analysis and merge results
            llm_results = await self.run_llm_analysis(audit_report)
            if llm_results:
                audit_report = self._merge_llm_into_report(audit_report, llm_results)

            # Save report
            report_paths = self.result_processor.save_audit_results(audit_report)

            return {
                'report': audit_report,
                'output_paths': report_paths
            }

        except Exception as e:
            self.logger.error(f"Accessibility audit failed: {e}")
            return create_error_report(urls, str(e))

    async def run_comprehensive_audit(self, urls: List[str]) -> Dict[str, Any]:
        if not urls:
            return create_empty_report()

        try:
            # from src.analyzer.integrated_audit_runner import IntegratedAuditRunner
            self.result_processor = ResultProcessor(self.config)

            integrated_runner = IntegratedAuditRunner(self.config)
            comprehensive_results = await integrated_runner.run_comprehensive_audit(urls)

            # Run LLM analysis and merge
            llm_results = await self.run_llm_analysis(comprehensive_results)
            if llm_results:
                comprehensive_results = self._merge_llm_into_report(comprehensive_results, llm_results)

            report_paths = self.result_processor.save_comprehensive_results(comprehensive_results)

            return {
                'report': comprehensive_results,
                'output_paths': report_paths
            }

        except Exception as e:
            self.logger.error(f"Comprehensive audit failed: {e}")
            return await self.run_accessibility_audit(urls)

    async def run_full_audit(self, audit_type: str = "comprehensive", min_page: int = 1, max_pages: int = None):

        urls = await self.run_crawl()

        print(f"\n--- Crawl ended. Found {len(urls)} URLs ---")
        for i, url in enumerate(urls, 1):
            print(f"{i}. {url}")
        print("----------------------------------------\n")

        # Apply min/max page range
        end = max_pages if max_pages else len(urls)
        selected_urls = urls[min_page - 1 : end]

        print(f"Selected pages {min_page} to {end} → {len(selected_urls)} URL(s) to audit:")
        for i, url in enumerate(selected_urls, min_page):
            print(f"  {i}. {url}")
        print("\nStarting the audit process...")

        if audit_type == "comprehensive":
            comprehensive_results = await self.run_comprehensive_audit(selected_urls)
            basic_results = await self.run_accessibility_audit(selected_urls)
            return {
                "crawled_urls": selected_urls,
                "comprehensive_audit": comprehensive_results,
                "basic_audit": basic_results,
                "audit_type": audit_type
            }
        else:
            # Only run basic audit
            basic_results = await self.run_accessibility_audit(selected_urls)
            return {
                "crawled_urls": selected_urls,
                "basic_audit": basic_results,
                "audit_type": audit_type
            }


async def main():
    print_banner()
    try:
        parser = argparse.ArgumentParser(description="A11ySense AI - Accessibility Audit Tool")
        parser.add_argument("--type", dest="audit_type", default="comprehensive",
                            choices=["basic", "comprehensive"],
                            help="Audit type: basic or comprehensive (default: comprehensive)")
        parser.add_argument("--min-page", type=int, default=1,
                            help="Start from this page number in crawl results (default: 1)")
        parser.add_argument("--max-pages", type=int, default=None,
                            help="End at this page number in crawl results (default: all pages)")
        args = parser.parse_args()

        # Validate range
        if args.min_page < 1:
            print("Error: --min-page must be 1 or greater.")
            return {"error": "invalid --min-page"}

        if args.max_pages and args.max_pages < args.min_page:
            print("Error: --max-pages must be greater than or equal to --min-page.")
            return {"error": "invalid page range"}

        tool = AccessibilityAuditTool()

        print(f"\nAudit type  : {args.audit_type}")
        print(f"Page range  : {args.min_page} to {args.max_pages if args.max_pages else 'end'}")

        results = await tool.run_full_audit(
            audit_type=args.audit_type,
            min_page=args.min_page,
            max_pages=args.max_pages
        )

        return results

    except Exception as e:
        return {"error": str(e)}


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    exit(exit_code)