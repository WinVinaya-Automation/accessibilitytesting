from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import List, Dict, Any
import httpx
import asyncio
import os
import uuid
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="A11ySense AI Gateway")

# Service URLs (would normally be in config/env)
SERVICES = {
    "crawler": "http://127.0.0.1:8001",
    "analyzer": "http://127.0.0.1:8002",
    "llm": "http://127.0.0.1:8003",
    "reporting": "http://127.0.0.1:8004",
}

class AuditJob(BaseModel):
    url: str
    audit_type: str = "comprehensive"
    min_page: int = 1       # Start page (1-based, inclusive)
    max_pages: int = 10     # End page (1-based, inclusive)
    max_depth: int = 3

# Simple in-memory task tracking
tasks = {}

async def run_audit_flow(task_id: str, job: AuditJob):
    tasks[task_id] = {"status": "starting", "url": job.url}

    async with httpx.AsyncClient(timeout=1800.0) as client:
        try:
            # 1. Crawl — crawl up to max_pages so we have enough URLs to slice
            tasks[task_id]["status"] = "crawling"
            # Send only url and max_depth — omitting max_pages entirely so the
            # crawler falls back to its config default (1000), giving us the full
            # site to slice from.  Sending None causes a 422 on the crawler side.
            crawl_resp = await client.post(f"{SERVICES['crawler']}/crawl", json={
                "url": job.url,
                "max_depth": job.max_depth
            })
            crawl_resp.raise_for_status()
            crawl_data = crawl_resp.json()

            # Deduplicate trailing-slash variants so that https://x.com and
            # https://x.com/ do NOT occupy two separate numbered positions.
            from urllib.parse import urlparse as _urlparse
            def _canonical(u):
                p = _urlparse(u)
                path = p.path.rstrip('/') or ''
                return f"{p.scheme}://{p.netloc}{path}" + (f"?{p.query}" if p.query else "")

            seen = {}
            for u in crawl_data["urls"]:
                c = _canonical(u)
                if c not in seen:
                    seen[c] = u   # keep first occurrence

            all_urls = sorted(seen.values(), key=_canonical)

            logger.info(f"Crawl ended for task {task_id}. Found {len(all_urls)} URLs total (after dedup).")

            # Slice URLs by 1-based page range (min_page to max_pages, inclusive).
            # Deduplication above ensures stable, gap-free numbering.
            start = max(0, job.min_page - 1)   # convert 1-based to 0-based index
            end   = job.max_pages               # slice end is exclusive, maps correctly
            urls  = all_urls[start:end]

            # If min_page is beyond what was crawled, that is a real error.
            if not urls:
                raise Exception(
                    f"No URLs found starting at page {job.min_page}. "
                    f"Site only has {len(all_urls)} URL(s) after deduplication."
                )

            # If max_pages exceeds the site size, just audit what exists — not an error.
            actual_end = min(job.max_pages, len(all_urls))
            if job.max_pages > len(all_urls):
                logger.warning(
                    f"max_pages={job.max_pages} exceeds site size ({len(all_urls)} URLs). "
                    f"Auditing all available URLs ({len(urls)})."
                )
                tasks[task_id]["warning"] = (
                    f"Requested up to page {job.max_pages} but site only has "
                    f"{len(all_urls)} URL(s). Auditing all {len(urls)} found."
                )

            logger.info(f"Page range {job.min_page}-{actual_end} -> {len(urls)} URL(s) selected for audit.")

            tasks[task_id]["urls_found"] = len(urls)
            tasks[task_id]["urls_list"] = urls
            tasks[task_id]["elements"] = crawl_data.get("elements", {})

            # 3. Audit selected URLs
            tasks[task_id]["status"] = "auditing"
            audit_resp = await client.post(f"{SERVICES['analyzer']}/audit", json={
                "urls": urls,
                "audit_type": job.audit_type
            })
            audit_resp.raise_for_status()
            audit_results = audit_resp.json()

            # 4. LLM Analysis (if comprehensive)
            if job.audit_type == "comprehensive":
                tasks[task_id]["status"] = "llm_analyzing"
                try:
                    llm_resp = await client.post(f"{SERVICES['llm']}/analyze", json={
                        "audit_results": audit_results
                    })
                    llm_resp.raise_for_status()
                    llm_analysis = llm_resp.json()["analysis"]
                    audit_results["llm_analysis"] = llm_analysis

                    logger.info(f"LLM returned {len(llm_analysis)} insights")

                    # Build lookup map: (url, rule_id) -> LLM element
                    llm_map = {}
                    for insight in llm_analysis:
                        iurl = insight.get("url", "")
                        for el in insight.get("elements", []):
                            llm_map[(iurl, el.get("rule_id", ""))] = el

                    logger.info(f"LLM map has {len(llm_map)} entries")

                    # Merge LLM fields back into each violation and pass
                    for page in audit_results.get("page_results", []):
                        purl = page.get("url", "")
                        for v in page.get("violations", []):
                            el = llm_map.get((purl, v.get("id", "")), {})
                            v["expected_result"] = el.get("expected_result", "")
                            v["actual_result"] = el.get("actual_result", "")
                            v["llm_description"] = el.get("description", "")
                            v["steps_to_reproduce"] = el.get("steps_to_reproduce", "")
                        for p in page.get("passes", []):
                            el = llm_map.get((purl, p.get("id", "")), {})
                            p["expected_result"] = el.get("expected_result", "")
                            p["actual_result"] = el.get("actual_result", "")
                            p["llm_description"] = el.get("description", "")
                            p["steps_to_reproduce"] = el.get("steps_to_reproduce", "")

                except Exception as e:
                    logger.error(f"LLM error: {e}")
                    tasks[task_id]["llm_error"] = str(e)

            # 5. Report Generation
            tasks[task_id]["status"] = "reporting"
            report_resp = await client.post(f"{SERVICES['reporting']}/generate", json={
                "audit_data": audit_results,
                "report_type": job.audit_type
            })
            report_resp.raise_for_status()
            report_paths = report_resp.json()["output_paths"]

            tasks[task_id]["status"] = "completed"
            tasks[task_id]["report_paths"] = report_paths

        except Exception as e:
            logger.error(f"Audit flow failed for task {task_id}: {e}")
            tasks[task_id]["status"] = "failed"
            tasks[task_id]["error"] = str(e)


@app.post("/start_audit")
async def start_audit(job: AuditJob, background_tasks: BackgroundTasks):
    task_id = str(uuid.uuid4())
    tasks[task_id] = {"status": "starting", "url": job.url}
    background_tasks.add_task(run_audit_flow, task_id, job)
    return {"task_id": task_id, "message": "Audit started in background"}


@app.get("/task/{task_id}")
async def get_task_status(task_id: str, include_details: bool = True):
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail="Task not found")

    task_data = tasks[task_id].copy()
    if not include_details:
        task_data.pop("urls_list", None)
        task_data.pop("elements", None)

    return task_data


@app.get("/health")
async def health():
    return {"status": "healthy", "service": "gateway"}