import os
import asyncio
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
import aiohttp
import json
from ..core.exceptions import LLMException
from ..utils.logger import setup_logger

@dataclass
class LLMInsight:
    url: str
    page_title: str
    elements: List[Dict[str, Any]]
    priority_issues: List[Dict[str, Any]]
    productivity_impact: Dict[str, Any]
    code_recommendations: List[Dict[str, str]]
    business_impact: Dict[str, Any]
    roi_calculation: Dict[str, float]

class GroqClient:
    def __init__(self, config: dict):
        self.config = config.get('llm', {})
        self.api_key = self.config.get('api_key')
        self.model = self.config.get('model', 'llama3-70b-8192')
        self.base_url = "https://api.groq.com/openai/v1/chat/completions"
        self.logger = setup_logger(__name__)
        
        if not self.api_key or self.api_key.startswith('${'):
            self.logger.warning("Groq API key not configured. LLM features will be disabled.")
            self.enabled = False
        else:
            self.enabled = True
    
    async def analyze_audit_results(self, audit_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Entry point for microservice to analyze raw audit report"""
        if not self.enabled:
            return []
            
        from types import SimpleNamespace
        
        mock_results = []
        for page in audit_results.get('page_results', []):
            mock_results.append(SimpleNamespace(
                url=page.get('url', 'unknown'),
                page_title=page.get('page_title', 'Unknown'),
                violations=page.get('violations', []),
                passes=page.get('passes', []),
                unique_insights=page.get('extended_audit', {})
            ))
            
        insights = await self.generate_accessibility_insights(mock_results)
        
        return [
            {
                "url": insight.url,
                "page_title": insight.page_title,
                "elements": insight.elements,
                "priority_issues": insight.priority_issues,
                "productivity_impact": insight.productivity_impact,
                "code_recommendations": insight.code_recommendations,
                "business_impact": insight.business_impact,
                "roi_calculation": insight.roi_calculation
            } for insight in insights
        ]
    
    async def generate_accessibility_insights(self, analysis_results: List[Any]) -> List[LLMInsight]:
        """Generate advanced insights using LLM"""
        if not self.enabled:
            self.logger.warning("LLM features are disabled. Returning empty insights.")
            return []
        
        insights = []
        for result in analysis_results:
            try:
                insight = await self._analyze_single_result(result)
                insights.append(insight)
            except Exception as e:
                self.logger.error(f"LLM analysis failed for {result.url}: {e}")
                insights.append(self._create_basic_insight(result))
        
        return insights
    
    async def _analyze_single_result(self, result: Any) -> LLMInsight:
        """Analyze single accessibility result using LLM"""
        prompt = self._build_expected_actual_prompt(result)
        response = await self._make_llm_request(prompt)
        return self._parse_llm_response(response, result.url, result.page_title)

    def _build_expected_actual_prompt(self, result: Any) -> str:
        """Builds a high-detail, prescriptive prompt for both Pass and Fail cases."""
        
        violations_text = "\n".join([
            f"- ID: {v.get('id','')}, Impact: {v.get('impact','')}, Summary: {v.get('help','')}, Tags: {v.get('tags',[])}"
            for v in result.violations[:30]
        ])
        
        passes_text = "\n".join([
            f"- ID: {p.get('id','')}, Summary: {p.get('help','')}, Tags: {p.get('tags',[])}"
            for p in result.passes[:30]
        ])
        
        prompt = f"""
You are a Senior WCAG 2.2 Accessibility Auditor. Conduct a deep-dive analysis for the page: {result.page_title} ({result.url}).

### MANDATORY CONTENT GUIDELINES:
1. **Expected Result**: State the exact WCAG threshold (e.g., "4.5:1 ratio", "3:1 for large text", "Unique ID attribute"). Include a directive on how this must be maintained or corrected.
2. **Actual Result**: 
    - **FAIL**: Detail the specific technical deviation causing the error on the page.
    - **PASS**: Explain the technical success (e.g., "The element correctly uses aria-labelledby to associate the title with the container").
3. **Description**: 
    - **FAIL**: Explain the user barrier, which specific disability group is blocked, and the frustration caused.
    - **PASS**: Explain the clear benefit of this implementation for end-users (e.g., "This allows screen reader users to skip non-essential content").
4. **Steps to Reproduce (CRITICAL)**:
    - **For FAIL cases**: Provide **MINIMUM 5-7 granular steps**. Do not use generic placeholders. Steps must include:
        - Specific browser tool usage (e.g., "Open Inspector", "Check Accessibility Tree").
        - Navigation/Keyboard actions (e.g., "Tab until the focus ring disappears").
        - The specific visual or technical observation that confirms the failure.
    - **For PASS cases**: Provide 3-4 steps to verify why this element is currently compliant.
5. **AI Suggested/Recommended Fix**: 
    - **FAIL**: Provide a specific, technical code remediation snippet or structural change.
    - **PASS**: Strictly set this field to "N/A".

### SCAN DATA:
FAILED RULES:
{violations_text if violations_text else "None"}

PASSED RULES:
{passes_text if passes_text else "None"}

### RESPONSE FORMAT:
Return ONLY a valid JSON array. No conversational text. Use '\\n' for new lines in 'steps_to_reproduce'.

[
  {{
    "rule_id": "string",
    "status": "Fail | Pass",
    "expected_result": "Prescriptive technical requirement + specific threshold + corrective action.",
    "actual_result": "Comprehensive technical explanation of why it failed or why it passed.",
    "description": "High-detail summary of user impact (negative for fail, positive for pass).",
    "steps_to_reproduce": "1. [Setup step]\\n2. [Tool usage]\\n3. [Action]\\n4. [Observation]\\n5. [Confirmation]\\n6. [Edge case check]\\n7. [Final result]",
    "ai_suggested_fix": "Code fix for Fail, or 'N/A' for Pass"
  }}
]
"""
        return prompt

    async def _make_llm_request(self, prompt: str) -> str:
        """Make request to Groq API with low temperature for strict adherence."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": "You are a Senior Accessibility Auditor. You provide detailed, technical, and prescriptive JSON responses without preamble or markdown."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": 0.2, # Low temperature for consistent JSON and formatting
            "max_tokens": 5000
        }
        
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(self.base_url, headers=headers, json=payload, timeout=90) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data['choices'][0]['message']['content']
                    else:
                        error_text = await response.text()
                        raise LLMException(f"Groq API error {response.status}: {error_text}")
            except Exception as e:
                raise LLMException(f"Groq API request failed: {e}")
    
    def _parse_llm_response(self, response: str, url: str, page_title: str = '') -> LLMInsight:
        """Parse LLM response into structured insight"""
        try:
            json_start = response.find('[')
            json_end = response.rfind(']') + 1
            if json_start != -1 and json_end != -1:
                json_str = response[json_start:json_end]
                elements = json.loads(json_str)
                return LLMInsight(
                    url=url,
                    page_title=page_title,
                    elements=elements,
                    priority_issues=[],
                    productivity_impact={},
                    code_recommendations=[],
                    business_impact={},
                    roi_calculation={}
                )
            raise ValueError("No JSON array found in response")
        except Exception as e:
            self.logger.error(f"Failed to parse LLM response: {e}")
            return self._create_basic_insight_from_response(response, url)
    
    def _create_basic_insight(self, result: Any) -> LLMInsight:
        """Fallback for when LLM processing fails."""
        return LLMInsight(
            url=result.url,
            page_title=getattr(result, 'page_title', 'Unknown'),
            elements=[],
            priority_issues=[],
            productivity_impact={},
            code_recommendations=[],
            business_impact={},
            roi_calculation={}
        )
    
    def _create_basic_insight_from_response(self, response: str, url: str) -> LLMInsight:
        """Fallback for when JSON parsing fails."""
        return LLMInsight(
            url=url,
            page_title='',
            elements=[],
            priority_issues=[{"issue": "Parsing Error", "description": "AI response was not in a valid JSON format."}],
            productivity_impact={"overall_score": 0},
            code_recommendations=[],
            business_impact={},
            roi_calculation={}
        )